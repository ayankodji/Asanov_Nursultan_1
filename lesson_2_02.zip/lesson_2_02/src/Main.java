public class Main {
    public static void main(String[] args) {
        int numberOfStudents = 10;
        int temperature = 15;
        boolean isSnowy = false;

        if (temperature > 10 && temperature < 30) { // && - логический оператор И (AND)
            System.out.println("Go to park");
        }

        if (numberOfStudents == 22 && temperature > 20) {
            System.out.println("Play Football");
        }

        if (temperature <= 15 || isSnowy) { // || - логический оператор ИЛИ (OR)
            System.out.println("Go to cinema!");
        }

        if (isSnowy || numberOfStudents < 5) {
            System.out.println("Go to cafe!");
        }

        if (numberOfStudents == 10 || temperature > 20 && temperature < 35) {
            // true || false && true => 1 + 0 * 1 => 1 + 0 = 1 (TRUE)
            System.out.println("Go to school");
        }

        if ((numberOfStudents == 10 || temperature > 20) && temperature < 35) {
            // (true || false) && true => (1 + 0) * 1 => 1 * 1 = 1 (TRUE)
            System.out.println("Go to work");
        }

        if (isSnowy) {
            System.out.println("Go by taxi");
        }

        if (!isSnowy) { // ! логический оператор отрицания НЕ (NOT)
            System.out.println("Walking");
        }

        if ((numberOfStudents != 10 || temperature > 20) && temperature < 35) {
            // (false || false) && true => (0 + 0) * 1 => 0 * 1 = 0 (FALSE)
            System.out.println("Go to home");
        }
    }
}
